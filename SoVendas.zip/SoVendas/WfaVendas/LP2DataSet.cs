﻿namespace WfaVendas
{


    partial class LP2DataSet
    {
        partial class pc_itemvendaDataTable
        {
        }
    }
}

